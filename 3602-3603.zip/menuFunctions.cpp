#include "menuFunctions.h"
#include <chrono>
typedef std::chrono::high_resolution_clock Clock;


bool fileExists(string filename)
{
    fstream file(filename.c_str());
    if(file.is_open() )
    {
        file.close();
        return true;
    }
    return false;
}




string getFilename()
{
    string defaultFilename = "small-file.txt";
    string inputFilename;
    cout<<"Give the name of the file you want to load"<<endl;
    cout<<"if nothing is given the program will load small-file.txt"<<endl;
    getline(cin,inputFilename);

    if(inputFilename.empty())
    {
        return defaultFilename;

    }
    else
    {
        if(fileExists(inputFilename))
            return inputFilename;
        else
        {
            cout<<"The file cant be found default will be loaded"<<endl;
            return defaultFilename;
        }
    }
}


void searchRandom(HashMap &a,BstNode *BSTroot,AvlTreeNode *AVLroot,int randomWordsIndex,string* & randomWords)
{
    int hashfound = 0;
    int bstfound = 0;
    int avlfound = 0;
    int counter = 0;



    //Binary


    auto start = chrono::high_resolution_clock::now();
    ios_base::sync_with_stdio(false);

    ofstream outfile("Output.txt");

    for(int i=0;i<randomWordsIndex;i++)
    {
        if(addin(randomWords[i]) < 0)
            continue;
        if(BstSearch(BSTroot,randomWords[i],counter))
        {
            outfile<<"Binary:"<<randomWords[i]<<" "<<counter<<endl;

            bstfound++;
        }
    }



    auto end = chrono::high_resolution_clock::now();

    double time_takenBin = chrono::duration_cast<chrono::nanoseconds>(end - start).count();
    time_takenBin *= 1e-9;

    cout << "Binary Tree Search Took : " << fixed
         << time_takenBin ;
    cout << " sec" << endl;
    outfile<<endl<<endl<<endl;
    outfile << "Binary Tree Search Took : " << fixed
         << time_takenBin ;
    outfile << " sec" << endl;
    outfile<<endl<<endl<<endl;




    //AVL

    start = chrono::high_resolution_clock::now();
    ios_base::sync_with_stdio(false);


    for(int i=0;i<randomWordsIndex;i++)
    {
        if(addin(randomWords[i]) < 0)
            continue;
        if(AvlSearch(AVLroot,randomWords[i],counter))
        {
            outfile<<"Avl:"<<randomWords[i]<<" "<<counter<<endl;

            avlfound++;
        }
    }


    end = chrono::high_resolution_clock::now();

    double time_takenAVL = chrono::duration_cast<chrono::nanoseconds>(end - start).count();
    time_takenAVL *= 1e-9;

    cout << "AVL Tree Search Took : " << fixed
         << time_takenAVL ;
    cout << " sec" << endl;
    outfile<<endl<<endl<<endl;
    outfile << "AVL Tree Search Took : " << fixed
         << time_takenAVL ;
    outfile << " sec" << endl;
    outfile<<endl<<endl<<endl;




    // Hash


    start = chrono::high_resolution_clock::now();
    ios_base::sync_with_stdio(false);


    for(int i=0;i<randomWordsIndex;i++)
    {
        if(addin(randomWords[i]) < 0)
            continue;
        if(a.FindElement(randomWords[i],counter))
        {
            outfile<<"Hash:"<<randomWords[i]<<" "<<counter<<endl;
            hashfound++;
        }
    }



    end = chrono::high_resolution_clock::now();
    double time_takenHash = chrono::duration_cast<chrono::nanoseconds>(end - start).count();
    time_takenHash *= 1e-9;

    cout << "Hash Search Took : " << fixed
         << time_takenHash;
    cout << " sec" << endl;
    outfile<<endl<<endl<<endl;
    outfile << "Hash Search Took : " << fixed
         << time_takenHash;
    outfile << " sec" << endl;

    //outfile << endl << hashfound << " "<<bstfound<< " "<<avlfound<<endl;

    outfile.close();
}


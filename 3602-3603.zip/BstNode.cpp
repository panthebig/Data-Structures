#include <iostream>
#include "BstNode.h"

using namespace std;


BstNode* GetNewNode(std::string idata)
{
    BstNode* newNode=new BstNode();
    newNode->data=idata;
    newNode->left=NULL;
    newNode->right=NULL;
    newNode->counter=1;
    return newNode;
}

BstNode* Insert(BstNode* root,std::string data)
{
    if(root==NULL)
    {
        root=GetNewNode(data);
    }
    else if(data < root->data)
    {
        root->left=Insert(root->left,data);
    }
    else if(data > root->data)
    {
        root->right=Insert(root->right,data);
    }
    else
    {
        root->counter++;
    }
    return root;

}

bool BstSearch(BstNode* root,std::string idata,int &C)
{
    if(root==NULL)
    {
        return false;
    }
    else if(root->data == idata)
    {
        C=root->counter;
        return true;
    }
    else if(root->data > idata)
    {
        return BstSearch(root->left,idata,C);
    }
    else
        return BstSearch(root->right,idata,C);
}

BstNode* DeleteEllement(BstNode* root,std::string idata,int i)
{
    struct BstNode* temp2;
    if(i==0) //checks one time how many times idata is in the text
    {
        temp2=BstSearchNode(root,idata);
        i++;
    }

    if(temp2->counter>=2)
    {
        cout<<"Before :  "<<temp2->counter<<endl;
        temp2->counter--;
        cout<<"after :  "<<temp2->counter<<endl;
        return root;
    }
    else
    {
        if(root == NULL)
        {
            return root;
        }
        else if(root->data > idata)
        {
            root->left = DeleteEllement(root->left,idata,i);
        }
        else if(root->data < idata)
        {
            root->right = DeleteEllement(root->right,idata,i);
        }
        else
        {
            if( (root->left==NULL) && (root->right==NULL) ) //Node doesnt have a kid
            {
                delete root;
                root = NULL;
            }
            else if (root->left == NULL)//No left kid
            {
                struct BstNode *temp = root;//temp and root point to the same thing
                root=root->right;
                delete temp;
            }
            else if(root->right==NULL)//No right kid
            {
                struct BstNode *temp = root;//temp and root point to the same thing
                root=root->left;
                delete temp;
            }
            else//has 2 kids
            {
                struct BstNode* temp = FindMin(root->right);
                root->data=temp->data;//The node to be deleted takes the smallest value of the right subtree
                root->right= DeleteEllement(root->right,temp->data,i);
            }

        }
        return root;
    }

}


BstNode* FindMin(BstNode* root)
{
    while(root->left!=NULL)
    {
        root=root->left;
    }
    return root;
}

BstNode* BstSearchNode(BstNode* root,std::string idata)
{
    if(root==NULL)
    {
        return NULL;
    }
    else if(root->data == idata)
    {
        return root;
    }
    else if(root->data > idata)
    {
        return BstSearchNode(root->left,idata);
    }
    else
        return BstSearchNode(root->right,idata);
}

void PreOrder(BstNode *root)
{
    if(root != NULL)//if the tree is empty,nothing will be shown
    {
        cout << root->data<<" , ";
        PreOrder(root->left);
        PreOrder(root->right);
    }
}

void PostOrder(BstNode *root)
{
    if(root != NULL)
    {
        PostOrder(root->left);
        PostOrder(root->right);
        cout << root->data<<" , ";
    }
}

void InOrder(BstNode *root)
{
    if(root != NULL)
    {
        InOrder(root->left);
        cout << root->data<<" , ";
        InOrder(root->right);
    }
}
